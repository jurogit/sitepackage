<?php

/**
 * Extension Manager/Repository config file for ext "bs_sitepackage".
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'BS Sitepackage',
    'description' => 'Bootstrap Sitepackage Extension for Typo3 v10.4',
    'category' => 'templates',
    'constraints' => [
        'depends' => [
            'bootstrap_package' => '11.0.0-11.0.99',
        ],
        'conflicts' => [
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'Juroweb\\BsSitepackage\\' => 'Classes',
        ],
    ],
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'Robert Juhasz',
    'author_email' => 'robertjuhasz@t-online.hu',
    'author_company' => 'Juroweb',
    'version' => '1.0.0',
];
